# WebProject
This is a PHP/HTML/CSS/JS based Web Project for my courseware at SRM IST, Chennai. It is a Flight Reservation System. It uses Apache server and mysql DB as backend.
