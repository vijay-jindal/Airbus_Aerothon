<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$servername = "localhost";
        $dbname = "xyzbooking";

        // Create connection
        $conn = new mysqli($servername,"root","", $dbname);


$sql = "select distinct user from trans";

$result = $conn->query($sql);
if($result->num_rows>0){
    
    while($row = $result->fetch_assoc()){
    $mail = new PHPMailer;
    $mail->isSMTP();                            // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';             // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                     // Enable SMTP authentication
    $mail->Username = 'rushabh.agarwal9@gmail.com';          // SMTP username
    $mail->Password = 'SRMktr#712'; // SMTP password
    $mail->SMTPSecure = 'tls';                  // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;                          // TCP port to connect to

    $mail->setFrom('rushabh.agarwal9@gmail.com', 'Airbus');
    $mail->addReplyTo('rushabh.agarwal9@gmail.com', 'Airbus');
    $mail->addAddress($row['user']);
    $user = $row['user'];
    echo $user;
    echo "<br>";
    $sqla = "select dtime, atime from trans where user='$user'";
    $resulta = $conn->query($sqla);

    $rowa = $resulta->fetch_assoc();
    echo "<br>";

    $mail->isHTML(true);  // Set email format to HTML
    $dest = $rowa['dtime'];
    $arr = $rowa['atime'];
    $bodyContent = '<h1>Airbus offers</h1>';
    $bodyContent .= '<p>You have got an exciting offer based on your recent booking on <b>Airbus</b>
    <br><br>
    Based on your booking from ' . $dest . ' to ' . $arr . '
    </p>';

    $mail->Subject = 'Offer from AirBus';
    $mail->Body    = $bodyContent;

    if(!$mail->send()) {
        echo 'Message could not be sent.';
        echo 'Mailer Error: ' . $mail->ErrorInfo;
    } else {
        echo 'Message has been sent to ';
    }
}
}
?>